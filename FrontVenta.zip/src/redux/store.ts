import { configureStore } from '@reduxjs/toolkit'
import { postApi } from './services/postApi'
import { userSlice } from './slices'
import {setupListeners} from '@reduxjs/toolkit/dist/query'

export const store = configureStore({
	reducer: {
		userReducer: userSlice,
		[postApi.reducerPath]: postApi.reducer,
	},

	middleware: (getDefaultMiddleware: any) =>
		getDefaultMiddleware().concat(postApi.middleware),
	devTools: true,
})

setupListeners(store.dispatch);
export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
