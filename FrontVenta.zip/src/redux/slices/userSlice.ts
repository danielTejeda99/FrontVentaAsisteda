import { PayloadAction, createSlice } from '@reduxjs/toolkit'

interface UserState {
	token: string
}

const initialState: UserState = {
	token: '',
}

export const userSlice = createSlice({
	name: 'user',
	initialState,
	reducers: {
		setUser(state, action: PayloadAction<string>) {
			console.log("action.payload",action.payload)
			state.token = action.payload
		},
		getUser(state){
			console.log("state",state.token)
		}

		// extraReducers: {
		//   [HYDRATE]: (state, action) => {
		//     return {
		//       ...state,
		//       ...action.payload.demito,
		//     }
		//   }
		// }
	},
})

export const { setUser, getUser} = userSlice.actions
export default userSlice.reducer
