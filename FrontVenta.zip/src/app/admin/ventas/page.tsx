
export default function Ventas() {
    return (
      <h1>Ventas</h1>
    )
  }
  