'use client'
import { Formik, Field, Form, FormikHelpers } from 'formik';
import Cookies from 'js-cookie';
import { useRouter } from 'next/navigation'
import {useAppDispatch,useAppSelector} from '@/redux/hooks';
import {setUser,getUser } from '@/redux/slices/userSlice'
interface Values {
    email: string;
    password : string;
}

const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.XbPfbIHMI6arZ3Y922BhjWgQzWXcXNrz0ogtVhfEd2o'
//TODO: optimizar este archivo
export default function Login() {
    const router = useRouter();
    const dispatch = useAppDispatch()
    return (
        <div>
            <h1>Signup</h1>
            <Formik
                initialValues={{                    
                    email: '',
                    password: ''
                }}
                onSubmit={(
                    values: Values,
                ) => {                   
                    dispatch(setUser(token))
                   /* Cookies.set('token', token );
                    router.replace('/');*/
                }}
            >
                <Form>
                    <label htmlFor="email">Email</label>
                    <Field
                        id="email"
                        name="email"
                        type="email"
                    />
                    <label htmlFor="password">password</label>
                    <Field id="password" name="password" type='password'/>

                    <button type="submit">Submit</button>
                </Form>
            </Formik>
            <button onClick={() => {
                console.log('aqui')
                dispatch(getUser())
            }}>estado</button>
        </div>
    )
}
